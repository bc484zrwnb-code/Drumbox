cmake_minimum_required(VERSION 3.22.1)
project(drumengine LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

find_package(oboe REQUIRED CONFIG)

add_library(drumengine SHARED
    native-lib.cpp
    DrumEngine.cpp)

target_link_libraries(drumengine oboe::oboe log android)
