#pragma once

#include <oboe/Oboe.h>

#include <array>
#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <vector>

// Boîte à rythmes : 8 voix, 16 pas, 16 patterns.
// Voix : 0 kick, 1 snare, 2 hat fermé, 3 hat ouvert, 4 clap, 5 tom, 6 rim, 7 cowbell
class DrumEngine : public oboe::AudioStreamDataCallback,
                   public oboe::AudioStreamErrorCallback {
public:
    static constexpr int kVoices = 8;
    static constexpr int kSteps = 16;
    static constexpr int kPatterns = 16;

    DrumEngine() { pos_.fill(-1); }

    bool start();
    void stop();

    void setPlaying(bool playing) { playing_.store(playing); }
    void setBpm(float bpm) { bpm_.store(bpm); }
    void setPattern(int p) { if (p >= 0 && p < kPatterns) pattern_.store(p); }
    void setVolume(float v) { volume_.store(v); }
    void setMute(int voice, bool mute);
    void trigger(int voice);
    int currentStep() const { return currentStep_.load(); }

    // Thread audio
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream *stream, void *audioData,
                                          int32_t numFrames) override;
    void onErrorAfterClose(oboe::AudioStream *stream, oboe::Result error) override;

private:
    bool openStreamLocked();
    void generateSamples();

    std::mutex mutex_;
    std::shared_ptr<oboe::AudioStream> stream_;
    bool running_ = false;

    int sampleRate_ = 48000;
    int channels_ = 2;
    std::array<std::vector<float>, kVoices> samples_;

    // Paramètres partagés UI <-> thread audio
    std::atomic<bool> playing_{false};
    std::atomic<float> bpm_{120.0f};
    std::atomic<int> pattern_{0};
    std::atomic<float> volume_{0.8f};
    std::atomic<uint32_t> muteMask_{0};
    std::atomic<uint32_t> manualMask_{0};
    std::atomic<int> currentStep_{-1};

    // État utilisé uniquement par le thread audio
    std::array<int, kVoices> pos_{};
    bool wasPlaying_ = false;
    int step_ = 0;
    double counter_ = 0.0;
};
