package com.example.drumbox

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NativeEngine.nStart()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { DrumScreen() }
            }
        }
    }

    override fun onDestroy() {
        NativeEngine.nStop()
        super.onDestroy()
    }
}

private val voiceNames = listOf("Kick", "Snare", "Hat", "Open hat", "Clap", "Tom", "Rim", "Cowbell")

@Composable
fun DrumScreen() {
    var playing by remember { mutableStateOf(false) }
    var bpm by remember { mutableFloatStateOf(120f) }
    var pattern by remember { mutableIntStateOf(0) }
    var volume by remember { mutableFloatStateOf(0.8f) }
    var step by remember { mutableIntStateOf(-1) }
    val muted = remember { mutableStateListOf(false, false, false, false, false, false, false, false) }

    // Synchronise l'état de l'UI avec le moteur natif
    LaunchedEffect(playing) { NativeEngine.nSetPlaying(playing) }
    LaunchedEffect(bpm) { NativeEngine.nSetBpm(bpm) }
    LaunchedEffect(pattern) { NativeEngine.nSetPattern(pattern) }
    LaunchedEffect(volume) { NativeEngine.nSetVolume(volume) }
    LaunchedEffect(Unit) { muted.forEachIndexed { i, m -> NativeEngine.nSetMute(i, m) } }
    LaunchedEffect(Unit) {
        while (true) {
            step = NativeEngine.nGetStep()
            delay(16)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("DrumBox", style = MaterialTheme.typography.headlineMedium)

        Button(onClick = { playing = !playing }, modifier = Modifier.fillMaxWidth()) {
            Text(if (playing) "Stop" else "Play")
        }

        Text("Tempo : ${bpm.roundToInt()} BPM")
        Slider(value = bpm, onValueChange = { bpm = it }, valueRange = 60f..200f)

        Text("Volume")
        Slider(value = volume, onValueChange = { volume = it }, valueRange = 0f..1f)

        Text("Pattern ${pattern + 1}")
        for (row in 0 until 4) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (col in 0 until 4) {
                    val p = row * 4 + col
                    PatternButton(p, p == pattern) { pattern = p }
                }
            }
        }

        // Voyants de pas
        Row(Modifier.fillMaxWidth()) {
            for (i in 0 until 16) {
                Box(
                    Modifier
                        .weight(1f)
                        .height(14.dp)
                        .padding(1.dp)
                        .background(
                            if (i == step) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                )
            }
        }

        // Pads + mute
        for (i in 0 until 8) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .weight(1f)
                        .height(52.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .pointerInput(i) {
                            detectTapGestures(onPress = { NativeEngine.nTrigger(i) })
                        },
                    contentAlignment = Alignment.Center
                ) { Text(voiceNames[i]) }
                Spacer(Modifier.width(8.dp))
                FilterChip(
                    selected = muted[i],
                    onClick = {
                        muted[i] = !muted[i]
                        NativeEngine.nSetMute(i, muted[i])
                    },
                    label = { Text("Mute") }
                )
            }
        }
    }
}

@Composable
private fun RowScope.PatternButton(index: Int, selected: Boolean, onClick: () -> Unit) {
    val label = (index + 1).toString()
    if (selected) {
        Button(onClick = onClick, modifier = Modifier.weight(1f)) { Text(label) }
    } else {
        OutlinedButton(onClick = onClick, modifier = Modifier.weight(1f)) { Text(label) }
    }
}
