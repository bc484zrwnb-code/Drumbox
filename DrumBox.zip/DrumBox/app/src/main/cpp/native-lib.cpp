#include <jni.h>

#include "DrumEngine.h"

static DrumEngine &engine() {
    static DrumEngine e;
    return e;
}

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_example_drumbox_NativeEngine_nStart(JNIEnv *, jobject) {
    return engine().start() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_example_drumbox_NativeEngine_nStop(JNIEnv *, jobject) { engine().stop(); }

JNIEXPORT void JNICALL
Java_com_example_drumbox_NativeEngine_nSetPlaying(JNIEnv *, jobject, jboolean playing) {
    engine().setPlaying(playing == JNI_TRUE);
}

JNIEXPORT void JNICALL
Java_com_example_drumbox_NativeEngine_nSetBpm(JNIEnv *, jobject, jfloat bpm) { engine().setBpm(bpm); }

JNIEXPORT void JNICALL
Java_com_example_drumbox_NativeEngine_nSetPattern(JNIEnv *, jobject, jint pattern) {
    engine().setPattern(pattern);
}

JNIEXPORT void JNICALL
Java_com_example_drumbox_NativeEngine_nSetMute(JNIEnv *, jobject, jint voice, jboolean mute) {
    engine().setMute(voice, mute == JNI_TRUE);
}

JNIEXPORT void JNICALL
Java_com_example_drumbox_NativeEngine_nSetVolume(JNIEnv *, jobject, jfloat volume) {
    engine().setVolume(volume);
}

JNIEXPORT void JNICALL
Java_com_example_drumbox_NativeEngine_nTrigger(JNIEnv *, jobject, jint voice) { engine().trigger(voice); }

JNIEXPORT jint JNICALL
Java_com_example_drumbox_NativeEngine_nGetStep(JNIEnv *, jobject) { return engine().currentStep(); }

}  // extern "C"
