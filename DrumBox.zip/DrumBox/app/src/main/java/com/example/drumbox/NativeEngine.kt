package com.example.drumbox

/** Pont JNI vers le moteur audio C++ (Oboe). */
object NativeEngine {
    init {
        System.loadLibrary("drumengine")
    }

    external fun nStart(): Boolean
    external fun nStop()
    external fun nSetPlaying(playing: Boolean)
    external fun nSetBpm(bpm: Float)
    external fun nSetPattern(pattern: Int)
    external fun nSetMute(voice: Int, mute: Boolean)
    external fun nSetVolume(volume: Float)
    external fun nTrigger(voice: Int)
    external fun nGetStep(): Int
}
