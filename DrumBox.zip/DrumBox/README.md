# DrumBox (étapes 1 et 2)

1. Android Studio > Open > choisis le dossier DrumBox (laisse Gradle synchroniser).
2. SDK Manager > SDK Tools : installe "NDK (Side by side)" et "CMake".
3. Branche un téléphone (débogage USB) et lance l'app.
4. Appuie sur Play, change de pattern, tape les pads.
