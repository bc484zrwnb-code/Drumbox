#include "DrumEngine.h"

#include <android/log.h>

#include <algorithm>
#include <cmath>

#define LOG_TAG "DrumEngine"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

// "x...x..." -> masque de 16 bits (le pas 0 est le bit de poids faible)
constexpr uint16_t P(const char *s) {
    uint16_t m = 0;
    for (int i = 0; i < 16 && s[i] != '\0'; ++i) {
        if (s[i] == 'x') m |= static_cast<uint16_t>(1u << i);
    }
    return m;
}

#define E "................"

// Ordre : kick, snare, hat fermé, hat ouvert, clap, tom, rim, cowbell
const uint16_t kPatternData[DrumEngine::kPatterns][DrumEngine::kVoices] = {
    /* 0 Rock      */ {P("x.......x.x....."), P("....x.......x..."), P("x.x.x.x.x.x.x.x."), P(E), P(E), P(E), P(E), P(E)},
    /* 1 Disco     */ {P("x...x...x...x..."), P("....x.......x..."), P("x...x...x...x..."), P("..x...x...x...x."), P(E), P(E), P(E), P(E)},
    /* 2 Electro   */ {P("x.....x...x....."), P("....x.......x..."), P("x.x.x.x.x.x.x.x."), P(E), P("....x.......x..."), P(E), P(E), P("......x.........")},
    /* 3 New wave  */ {P("x.......x......."), P("....x.......x..."), P("x.x.x.x.x.x.x.x."), P(E), P(E), P("..............x."), P(".......x........"), P(E)},
    /* 4 Stomp     */ {P("x.....x.x......."), P("....x.......x..x"), P("x.x.x.x.x.x.x.x."), P(E), P(E), P(E), P(E), P(E)},
    /* 5 Four floor*/ {P("x...x...x...x..."), P(E), P(".x.x.x.x.x.x.x.x"), P("..x...x...x...x."), P("....x.......x..."), P(E), P(E), P(E)},
    /* 6 Ballad    */ {P("x.......x......."), P("........x......."), P("x...x...x...x..."), P(E), P(E), P(E), P("....x.......x..."), P(E)},
    /* 7 Tom groove*/ {P("x...x.......x..."), P("....x.......x..."), P("x.x.x.x.x.x.x.x."), P(E), P(E), P("..........x.xxx."), P(E), P(E)},
    /* 8 Funk      */ {P("x..x..x...x..x.."), P("....x..x.x..x..."), P("x.x.x.x.x.x.x.x."), P("...............x"), P(E), P(E), P(E), P(E)},
    /* 9 Reggae    */ {P("........x......."), P("........x......."), P("..x...x...x...x."), P(E), P(E), P(E), P("....x.......x..."), P(E)},
    /* 10 Punk     */ {P("x.x...x.x.x...x."), P("....x.......x..."), P("x.x.x.x.x.x.x.x."), P(E), P(E), P(E), P(E), P(E)},
    /* 11 Latin    */ {P("x..x..x...x.x..."), P(E), P("x.x.x.x.x.x.x.x."), P(E), P(E), P(E), P("..x..x..x..x..x."), P("x...x...x...x...")},
    /* 12 Half-time*/ {P("x.........x....."), P("........x......."), P("x.x.x.x.x.x.x.x."), P(E), P("........x......."), P(E), P(E), P(E)},
    /* 13 Break    */ {P("x.....x...x....."), P("....x..x.x..x..."), P("x.x.x.x.x.x.x.x."), P(E), P(E), P(E), P(E), P(E)},
    /* 14 Tribal   */ {P("x.......x......."), P(E), P("x.x.x.x.x.x.x.x."), P(E), P(E), P("..x.x...x.x.x..."), P(E), P("....x.......x...")},
    /* 15 Minimal  */ {P("x.......x......."), P(E), P("..x...x...x...x."), P(".............x.."), P("....x.......x..."), P(E), P(E), P(E)},
};

}  // namespace

bool DrumEngine::start() {
    std::lock_guard<std::mutex> lock(mutex_);
    running_ = true;
    if (stream_) return true;
    return openStreamLocked();
}

void DrumEngine::stop() {
    std::shared_ptr<oboe::AudioStream> s;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        running_ = false;
        s = std::move(stream_);
        stream_.reset();
    }
    if (s) {
        s->stop();
        s->close();
    }
}

bool DrumEngine::openStreamLocked() {
    oboe::AudioStreamBuilder builder;
    builder.setDirection(oboe::Direction::Output)
        ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Exclusive)
        ->setFormat(oboe::AudioFormat::Float)
        ->setChannelCount(oboe::ChannelCount::Stereo)
        ->setUsage(oboe::Usage::Media)
        ->setDataCallback(this)
        ->setErrorCallback(this);

    oboe::Result r = builder.openStream(stream_);
    if (r != oboe::Result::OK) {
        LOGE("openStream failed: %s", oboe::convertToText(r));
        stream_.reset();
        return false;
    }

    sampleRate_ = stream_->getSampleRate();
    channels_ = stream_->getChannelCount();
    stream_->setBufferSizeInFrames(stream_->getFramesPerBurst() * 2);
    generateSamples();

    r = stream_->requestStart();
    if (r != oboe::Result::OK) {
        LOGE("requestStart failed: %s", oboe::convertToText(r));
        stream_->close();
        stream_.reset();
        return false;
    }
    return true;
}

void DrumEngine::onErrorAfterClose(oboe::AudioStream *, oboe::Result) {
    // Ex. : casque débranché -> on rouvre le flux
    std::lock_guard<std::mutex> lock(mutex_);
    stream_.reset();
    if (running_) openStreamLocked();
}

void DrumEngine::setMute(int voice, bool mute) {
    if (voice < 0 || voice >= kVoices) return;
    const uint32_t bit = 1u << voice;
    if (mute) muteMask_.fetch_or(bit);
    else muteMask_.fetch_and(~bit);
}

void DrumEngine::trigger(int voice) {
    if (voice < 0 || voice >= kVoices) return;
    manualMask_.fetch_or(1u << voice);
}

// Sons synthétisés (originaux), générés à la fréquence d'échantillonnage du flux.
void DrumEngine::generateSamples() {
    const float sr = static_cast<float>(sampleRate_);
    const float twoPi = 6.2831853f;
    uint32_t seed = 12345u;
    auto noise = [&seed]() {
        seed = seed * 1664525u + 1013904223u;
        return (static_cast<int32_t>(seed >> 8) / 8388608.0f) - 1.0f;
    };

    auto make = [&](float seconds, auto fn) {
        std::vector<float> v(static_cast<size_t>(seconds * sr));
        for (size_t i = 0; i < v.size(); ++i) v[i] = fn(static_cast<float>(i) / sr);
        float peak = 0.f;
        for (float x : v) peak = std::max(peak, std::fabs(x));
        if (peak > 0.f) for (float &x : v) x *= 0.9f / peak;
        const size_t fade = std::min<size_t>(v.size(), 64);
        for (size_t i = 0; i < fade; ++i) v[v.size() - 1 - i] *= static_cast<float>(i) / static_cast<float>(fade);
        return v;
    };

    float phaseK = 0.f, phaseT = 0.f;
    float prevC = 0.f, prevO = 0.f, prevClap = 0.f;

    // 0 Kick
    samples_[0] = make(0.4f, [&](float t) {
        float f = 45.f + 130.f * std::exp(-t * 40.f);
        phaseK += twoPi * f / sr;
        return std::sin(phaseK) * std::exp(-t * 8.f) + noise() * std::exp(-t * 400.f) * 0.3f;
    });

    // 1 Snare
    samples_[1] = make(0.25f, [&](float t) {
        float tone = std::sin(twoPi * 185.f * t) * std::exp(-t * 28.f) * 0.6f;
        return noise() * std::exp(-t * 20.f) * 0.8f + tone;
    });

    // 2 Hat fermé
    samples_[2] = make(0.08f, [&](float t) {
        float n = noise();
        float hp = n - prevC;
        prevC = n;
        return hp * std::exp(-t * 75.f);
    });

    // 3 Hat ouvert
    samples_[3] = make(0.4f, [&](float t) {
        float n = noise();
        float hp = n - prevO;
        prevO = n;
        return hp * std::exp(-t * 9.f);
    });

    // 4 Clap
    samples_[4] = make(0.28f, [&](float t) {
        const float bursts[3] = {0.f, 0.011f, 0.023f};
        float env = 0.f;
        for (float b : bursts) if (t >= b) env += std::exp(-(t - b) * 140.f);
        if (t >= 0.03f) env += 1.2f * std::exp(-(t - 0.03f) * 22.f);
        float n = noise();
        float band = n - 0.8f * prevClap;
        prevClap = n;
        return band * env;
    });

    // 5 Tom
    samples_[5] = make(0.45f, [&](float t) {
        float f = 85.f + 75.f * std::exp(-t * 18.f);
        phaseT += twoPi * f / sr;
        return std::sin(phaseT) * std::exp(-t * 7.f);
    });

    // 6 Rim
    samples_[6] = make(0.1f, [&](float t) {
        return (std::sin(twoPi * 1750.f * t) + 0.6f * std::sin(twoPi * 2650.f * t)) * std::exp(-t * 55.f);
    });

    // 7 Cowbell
    samples_[7] = make(0.4f, [&](float t) {
        auto sq = [&](float f) { return std::sin(twoPi * f * t) >= 0.f ? 1.f : -1.f; };
        return (sq(540.f) + sq(800.f)) * 0.5f * std::exp(-t * 10.f);
    });
}

oboe::DataCallbackResult DrumEngine::onAudioReady(oboe::AudioStream *, void *audioData,
                                                  int32_t numFrames) {
    auto *out = static_cast<float *>(audioData);
    const int ch = channels_;
    const uint32_t mute = muteMask_.load();
    const bool playing = playing_.load();
    const int pattern = pattern_.load();
    const float volume = volume_.load();
    const double samplesPerStep = static_cast<double>(sampleRate_) * 60.0 /
                                  (static_cast<double>(std::max(30.f, bpm_.load())) * 4.0);

    auto fire = [&](int v) {
        if (mute & (1u << v)) return;
        if (v == 2) pos_[3] = -1;  // le hat fermé coupe le hat ouvert
        pos_[v] = 0;
    };

    if (playing && !wasPlaying_) {
        step_ = 0;
        counter_ = 0.0;
    }
    if (!playing && wasPlaying_) currentStep_.store(-1);
    wasPlaying_ = playing;

    const uint32_t manual = manualMask_.exchange(0);
    for (int v = 0; v < kVoices; ++v) if (manual & (1u << v)) fire(v);

    for (int i = 0; i < numFrames; ++i) {
        if (playing) {
            if (counter_ <= 0.0) {
                for (int v = 0; v < kVoices; ++v) {
                    if (kPatternData[pattern][v] & (1u << step_)) fire(v);
                }
                currentStep_.store(step_);
                step_ = (step_ + 1) % kSteps;
                counter_ += samplesPerStep;
            }
            counter_ -= 1.0;
        }

        float s = 0.f;
        for (int v = 0; v < kVoices; ++v) {
            int &p = pos_[v];
            if (p >= 0) {
                s += samples_[v][p] * 0.5f;
                if (++p >= static_cast<int>(samples_[v].size())) p = -1;
            }
        }
        s = std::tanh(s * volume);
        for (int c = 0; c < ch; ++c) out[i * ch + c] = s;
    }
    return oboe::DataCallbackResult::Continue;
}
